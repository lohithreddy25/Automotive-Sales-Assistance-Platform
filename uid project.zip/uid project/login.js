
const signInForm = document.getElementById('signInForm');
const signUpForm = document.getElementById('signUpForm');
const forgotPasswordForm = document.getElementById('forgotPasswordForm');
const resetPasswordForm = document.getElementById('resetPasswordForm');
const signInLink = document.getElementById('signInLink');
const signUpLink = document.getElementById('signUpLink');
const forgotPasswordLink = document.getElementById('forgotPasswordLink');
const resetPasswordLink = document.getElementById('resetPasswordLink');

signInLink.addEventListener('click', () => {
    signInForm.style.display = 'block';
    signUpForm.style.display = 'none';
    forgotPasswordForm.style.display = 'none';
    resetPasswordForm.style.display = 'none';
    signInLink.classList.add('active-link');
    signUpLink.classList.remove('active-link');
    forgotPasswordLink.classList.remove('active-link');
    resetPasswordLink.classList.remove('active-link');
});

signUpLink.addEventListener('click', () => {
    signInForm.style.display = 'none';
    signUpForm.style.display = 'block';
    forgotPasswordForm.style.display = 'none';
    resetPasswordForm.style.display = 'none';
    signInLink.classList.remove('active-link');
    signUpLink.classList.add('active-link');
    forgotPasswordLink.classList.remove('active-link');
    resetPasswordLink.classList.remove('active-link');
});

forgotPasswordLink.addEventListener('click', () => {
    signInForm.style.display = 'none';
    signUpForm.style.display = 'none';
    forgotPasswordForm.style.display = 'block';
    resetPasswordForm.style.display = 'none';
    signInLink.classList.remove('active-link');
    signUpLink.classList.remove('active-link');
    forgotPasswordLink.classList.add('active-link');
    resetPasswordLink.classList.remove('active-link');
});

resetPasswordLink.addEventListener('click', () => {
    signInForm.style.display = 'block';
    signUpForm.style.display = 'none';
    forgotPasswordForm.style.display = 'none';
    resetPasswordForm.style.display = 'none';
    signInLink.classList.add('active-link');
    signUpLink.classList.remove('active-link');
    forgotPasswordLink.classList.remove('active-link');
    resetPasswordLink.classList.remove('active-link');
});

    // Function to hide the form when a button is clicked
function hideForm() {
    signInForm.style.display = 'none';
    signUpForm.style.display = 'none';
    forgotPasswordForm.style.display = 'none';
    resetPasswordForm.style.display = 'none';
    signInLink.classList.remove('active-link');
    signUpLink.classList.remove('active-link');
    forgotPasswordLink.classList.remove('active-link');
    resetPasswordLink.classList.remove('active-link');
}